﻿#include "enemy.h"

Enemy::Enemy()
: dx(1)
{
}
void Enemy::SetCenter(const int& x, const int& y)
{
	_x = x;
	_y = y;
}
void Enemy::Update()
{
}
void Enemy::Draw(char* board)
{
}


