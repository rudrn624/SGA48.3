﻿#include "Stack.h"

Stack::Stack()
{
}
Stack::~Stack()
{
}

void Stack::push(const data_type& v)
{
}
void Stack::pop()
{
}
Stack::data_type Stack::top() const
{
	return 0;
}
Stack::size_type Stack::size() const
{
	return 0;
}
bool Stack::empty() const
{
	return false;
}
void Stack::print() const
{
}
