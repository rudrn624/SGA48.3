﻿#pragma once

#include "LinkedList.h"

class Queue
{
};