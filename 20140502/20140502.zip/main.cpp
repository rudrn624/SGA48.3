﻿#include <iostream>
#include <conio.h>
#include "Stack.h"

using namespace std;

int main(void)
{
	const int count = 10;
	Stack a;

	for (int i = 0; i < count; i++)
	{
		a.push(i);
		a.print();
	}

	for (int i = 0; i < count; i++)
	{
		a.pop();
		a.print();
	}

	_getch();
	return 0;
}