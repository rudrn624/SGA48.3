﻿#include <iostream>
#include <conio.h>
#include "Stack.h"
#include "Queue.h"

using namespace std;

int main(void)
{
	const int count = 10;
	//Stack a;

	//for (int i = 0; i < count; i++)
	//{
	//	a.push(i);
	//	a.print();
	//	cout << "=================" << endl;
	//	_getch();
	//}

	//for (int i = 0; i < count; i++)
	//{
	//	a.pop();
	//	if (a.empty())
	//		cout << "stack is empty" << endl;
	//	else
	//		a.print();

	//	cout << "=================" << endl;
	//	_getch();
	//}

	//Queue b;

	//for (int i = 0; i < count; i++)
	//{
	//	b.push(i);
	//	b.print();
	//	cout << "=================" << endl;
	//	_getch();
	//}

	//for (int i = 0; i < count; i++)
	//{
	//	b.pop();
	//	if (b.empty())
	//		cout << "queue is empty" << endl;
	//	else
	//		b.print();

	//	cout << "=================" << endl;
	//	_getch();
	//}

	_getch();
	return 0;
}